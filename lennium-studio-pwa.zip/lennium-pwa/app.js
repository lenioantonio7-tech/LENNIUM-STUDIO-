/* ==========================================================================
   LENNIUM STUDIO — PWA
   Motor de áudio real via Web Audio API + interface vanilla JS (sem build).
   ========================================================================== */

// ---------- Constantes ----------
const TRACK_COLORS = ['#22d3ee', '#8b7cf6', '#818cf8', '#2dd4bf', '#f472b6', '#facc15', '#4ade80', '#fb923c', '#38bdf8', '#e879f9'];
const NOTE_NAMES = ['C','C#','D','D#','E','F','F#','G','G#','A','A#','B'];
const SCALE_INTERVALS = [0, 2, 4, 5, 7, 9, 11];
const MAX_TRACKS = 10;
const WF_POINTS = 320;
let nextId = 1;
let nextClipId = 1;

// ---------- Modelo de dados ----------
function makeTrack(name, color) {
  return {
    id: 't' + nextId++, name, color, armed: false, solo: false, mute: false,
    volume: 0, pan: 0, low: 0, high: 0, presence: 0, reverb: 0, comp: false,
    delayTime: 0.28, delayFeedback: 0.3, delayMix: 0,
    denoise: 0, autotuneOn: false, autotuneKey: 'C', autotuneAmount: 65,
    clips: [],
  };
}
function makeClip(buffer, waveform, offset) {
  return { id: 'c' + nextClipId++, buffer, waveform, bufferDuration: buffer.duration, offset, trimStart: 0, trimEnd: buffer.duration };
}
function clipEnd(c) { return c.offset + (c.trimEnd - c.trimStart); }
function trackEnd(t) { return t.clips.reduce((m, c) => Math.max(m, clipEnd(c)), 0); }
function projectDuration(tracks) { return Math.max(...tracks.map(trackEnd), 10); }
function fmtTime(s) { const m = Math.floor(s / 60); const sec = Math.floor(s % 60); return `${m}:${sec.toString().padStart(2, '0')}`; }
function dbToGain(db) { return Math.pow(10, db / 20); }

// ---------- DSP: autotune / denoiser ----------
function scaleFrequencies(rootIndex) {
  const freqs = [];
  for (let n = 24; n <= 96; n++) {
    const pc = ((n % 12) + 12) % 12;
    const rel = ((pc - rootIndex) + 12) % 12;
    if (SCALE_INTERVALS.includes(rel)) freqs.push(440 * Math.pow(2, (n - 69) / 12));
  }
  return freqs;
}
function nearestFreq(freqs, target) {
  let best = freqs[0], bestDiff = Infinity;
  for (const f of freqs) { const d = Math.abs(Math.log2(f / target)); if (d < bestDiff) { bestDiff = d; best = f; } }
  return best;
}
function detectPitch(buf, sampleRate) {
  const SIZE = buf.length;
  let rms = 0; for (let i = 0; i < SIZE; i++) rms += buf[i] * buf[i];
  rms = Math.sqrt(rms / SIZE);
  if (rms < 0.012) return null;
  const minLag = Math.floor(sampleRate / 500);
  const maxLag = Math.min(Math.floor(sampleRate / 70), Math.floor(SIZE / 2));
  let bestLag = -1, bestCorr = 0;
  for (let lag = minLag; lag <= maxLag; lag++) {
    let corr = 0; for (let i = 0; i < SIZE - lag; i++) corr += buf[i] * buf[i + lag];
    corr /= (SIZE - lag);
    if (corr > bestCorr) { bestCorr = corr; bestLag = lag; }
  }
  if (bestLag <= 0 || bestCorr < 0.0008) return null;
  return sampleRate / bestLag;
}
function createAutotuneNode(ctx, id, settingsRef) {
  const node = ctx.createScriptProcessor(2048, 1, 1);
  const ringSize = 8192;
  const ring = new Float32Array(ringSize);
  let writeIdx = 0, readIdx = 0, currentRatio = 1;
  node.onaudioprocess = (e) => {
    const input = e.inputBuffer.getChannelData(0);
    const output = e.outputBuffer.getChannelData(0);
    const cfg = settingsRef[id] || {};
    for (let i = 0; i < input.length; i++) { ring[writeIdx] = input[i]; writeIdx = (writeIdx + 1) % ringSize; }
    if (cfg.autotuneOn) {
      const freq = detectPitch(input, ctx.sampleRate);
      if (freq && freq > 60 && freq < 1000) {
        const freqs = scaleFrequencies(NOTE_NAMES.indexOf(cfg.autotuneKey || 'C'));
        const target = nearestFreq(freqs, freq);
        const amt = (cfg.autotuneAmount ?? 65) / 100;
        const desired = 1 + (target / freq - 1) * amt;
        currentRatio += (desired - currentRatio) * 0.35;
      }
    } else currentRatio += (1 - currentRatio) * 0.35;
    let gap = writeIdx - readIdx; if (gap < 0) gap += ringSize;
    const targetGap = ringSize / 2;
    if (Math.abs(gap - targetGap) > ringSize * 0.4) readIdx = (writeIdx - targetGap + ringSize) % ringSize;
    for (let i = 0; i < output.length; i++) {
      const i0 = Math.floor(readIdx) % ringSize, i1 = (i0 + 1) % ringSize, frac = readIdx - Math.floor(readIdx);
      output[i] = ring[i0] * (1 - frac) + ring[i1] * frac;
      readIdx += currentRatio; if (readIdx >= ringSize) readIdx -= ringSize;
    }
  };
  return node;
}
function createDenoiseNode(ctx, id, settingsRef) {
  const node = ctx.createScriptProcessor(1024, 1, 1);
  let envelope = 1;
  node.onaudioprocess = (e) => {
    const input = e.inputBuffer.getChannelData(0);
    const output = e.outputBuffer.getChannelData(0);
    const amt = (settingsRef[id]?.denoise || 0) / 100;
    if (amt <= 0.001) { output.set(input); return; }
    let rms = 0; for (let i = 0; i < input.length; i++) rms += input[i] * input[i];
    rms = Math.sqrt(rms / input.length);
    const threshold = 0.015 + amt * 0.06;
    const targetGain = rms < threshold ? 1 - amt * 0.92 : 1;
    const coeff = targetGain < envelope ? 0.5 : 0.12;
    envelope += (targetGain - envelope) * coeff;
    for (let i = 0; i < input.length; i++) output[i] = input[i] * envelope;
  };
  return node;
}
function sampleWaveform(audioBuffer, points = WF_POINTS) {
  const data = audioBuffer.getChannelData(0);
  const blockSize = Math.max(1, Math.floor(data.length / points));
  const wf = [];
  for (let i = 0; i < points; i++) {
    let sum = 0; const start = i * blockSize;
    for (let j = 0; j < blockSize; j++) sum += Math.abs(data[start + j] || 0);
    wf.push(sum / blockSize);
  }
  const max = Math.max(...wf, 0.001);
  return wf.map(v => v / max);
}
function bufferToWav(buffer, bitDepth) {
  const numCh = buffer.numberOfChannels;
  const bytesPerSample = bitDepth === 24 ? 3 : 2;
  const length = buffer.length * numCh * bytesPerSample + 44;
  const arrBuf = new ArrayBuffer(length);
  const view = new DataView(arrBuf);
  const writeStr = (o, s) => { for (let i = 0; i < s.length; i++) view.setUint8(o + i, s.charCodeAt(i)); };
  writeStr(0, 'RIFF'); view.setUint32(4, length - 8, true); writeStr(8, 'WAVE');
  writeStr(12, 'fmt '); view.setUint32(16, 16, true); view.setUint16(20, 1, true);
  view.setUint16(22, numCh, true); view.setUint32(24, buffer.sampleRate, true);
  view.setUint32(28, buffer.sampleRate * numCh * bytesPerSample, true); view.setUint16(32, numCh * bytesPerSample, true);
  view.setUint16(34, bitDepth, true); writeStr(36, 'data'); view.setUint32(40, length - 44, true);
  let offset = 44;
  const channels = []; for (let i = 0; i < numCh; i++) channels.push(buffer.getChannelData(i));
  for (let i = 0; i < buffer.length; i++) {
    for (let ch = 0; ch < numCh; ch++) {
      const s = Math.max(-1, Math.min(1, channels[ch][i]));
      if (bitDepth === 24) {
        const v = s < 0 ? s * 0x800000 : s * 0x7fffff;
        view.setUint8(offset, v & 0xff); view.setUint8(offset + 1, (v >> 8) & 0xff); view.setUint8(offset + 2, (v >> 16) & 0xff);
        offset += 3;
      } else { view.setInt16(offset, s < 0 ? s * 0x8000 : s * 0x7fff, true); offset += 2; }
    }
  }
  return new Blob([arrBuf], { type: 'audio/wav' });
}

/* ==========================================================================
   ESTADO
   ========================================================================== */
const state = {
  view: 'timeline',
  tracks: [makeTrack('Audio 1', TRACK_COLORS[0]), makeTrack('Track 2', TRACK_COLORS[1]), makeTrack('Track 3', TRACK_COLORS[2]), makeTrack('Audio 4', TRACK_COLORS[3])],
  isRecording: false, isPlaying: false, isExporting: false,
  armedTrack: null, status: 'Pronto — até 10 faixas, 30 min por faixa',
  playhead: 0, levels: {}, masterCeiling: -1, pxPerSec: 16,
  selected: null, exportBits: 24, exportRate: 48000,
};

const audio = {
  ctx: null, mediaRecorder: null, chunks: [], sourceNodes: [], stream: null,
  playStart: { perf: 0, resumeFrom: 0 }, raf: null, reverbBuffer: null, recordStartOffset: 0,
};
let liveSettings = {};
function syncLiveSettings() { liveSettings = {}; state.tracks.forEach(t => { liveSettings[t.id] = t; }); }

function getCtx() {
  if (!audio.ctx) audio.ctx = new (window.AudioContext || window.webkitAudioContext)();
  return audio.ctx;
}
function getReverbIR(ctx) {
  if (audio.reverbBuffer) return audio.reverbBuffer;
  const len = ctx.sampleRate * 1.8;
  const ir = ctx.createBuffer(2, len, ctx.sampleRate);
  for (let ch = 0; ch < 2; ch++) { const d = ir.getChannelData(ch); for (let i = 0; i < len; i++) d[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / len, 2.2); }
  audio.reverbBuffer = ir;
  return ir;
}

function findTrack(id) { return state.tracks.find(t => t.id === id); }
function updateTrack(id, patch) { Object.assign(findTrack(id), patch); }
function updateClip(trackId, clipId, patch) {
  const t = findTrack(trackId); const c = t.clips.find(c => c.id === clipId); Object.assign(c, patch);
}

function addTrack() {
  if (state.tracks.length >= MAX_TRACKS) { state.status = `Limite de ${MAX_TRACKS} faixas atingido`; render(); return; }
  state.tracks.push(makeTrack(`Track ${state.tracks.length + 1}`, TRACK_COLORS[state.tracks.length % TRACK_COLORS.length]));
  state.status = 'Faixa adicionada'; render();
}
function removeTrack(id) {
  state.tracks = state.tracks.filter(t => t.id !== id);
  if (state.armedTrack === id) state.armedTrack = null;
  render();
}
function toggleArm(id) {
  state.armedTrack = state.armedTrack === id ? null : id;
  state.tracks.forEach(t => { t.armed = t.id === id ? !t.armed : false; });
  render();
}
function toggleSolo(id) { const t = findTrack(id); t.solo = !t.solo; render(); }
function toggleMute(id) { const t = findTrack(id); t.mute = !t.mute; render(); }
function toggleComp(id) { const t = findTrack(id); t.comp = !t.comp; render(); }
function toggleAutotune(id) { const t = findTrack(id); t.autotuneOn = !t.autotuneOn; render(); }
function applyVoicePreset(id) { updateTrack(id, { low: -4, presence: 5, high: 2, denoise: 25 }); render(); }

/* ==========================================================================
   CAPTAÇÃO (gravação pelo microfone)
   ========================================================================== */
async function startRecording() {
  if (!state.armedTrack) { state.status = 'Arma uma faixa antes de gravar (botão vermelho R)'; render(); return; }
  try {
    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    audio.stream = stream;
    const mr = new MediaRecorder(stream);
    audio.mediaRecorder = mr;
    audio.chunks = [];
    audio.recordStartOffset = state.playhead;
    mr.ondataavailable = e => audio.chunks.push(e.data);
    mr.onstop = async () => {
      const blob = new Blob(audio.chunks, { type: 'audio/webm' });
      const arrayBuf = await blob.arrayBuffer();
      const ctx = getCtx();
      try {
        const audioBuffer = await ctx.decodeAudioData(arrayBuf);
        const wf = sampleWaveform(audioBuffer);
        const clip = makeClip(audioBuffer, wf, audio.recordStartOffset);
        findTrack(state.armedTrack).clips.push(clip);
        state.status = 'Gravação adicionada à faixa';
      } catch (err) { state.status = 'Erro ao processar a gravação'; }
      stream.getTracks().forEach(t => t.stop());
      render();
    };
    mr.start();
    state.isRecording = true; state.status = 'A gravar...'; render();
  } catch (err) { state.status = 'Permissão de microfone negada ou indisponível'; render(); }
}
function stopRecording() {
  if (audio.mediaRecorder && state.isRecording) audio.mediaRecorder.stop();
  state.isRecording = false;
}

/* ==========================================================================
   IMPORTAÇÃO DE ÁUDIO (multi-formato: wav, mp3, ogg, m4a/aac — consoante o browser)
   ========================================================================== */
function triggerImport() { document.getElementById('fileImport').click(); }
async function handleImportFiles(e) {
  const files = Array.from(e.target.files || []);
  if (!files.length) return;
  const ctx = getCtx();
  let targetId = state.armedTrack;
  for (const file of files) {
    try {
      const arrayBuf = await file.arrayBuffer();
      const audioBuffer = await ctx.decodeAudioData(arrayBuf);
      const wf = sampleWaveform(audioBuffer);
      if (!targetId) {
        if (state.tracks.length >= MAX_TRACKS) { state.status = 'Limite de 10 faixas atingido — importação parcial'; break; }
        const t = makeTrack(file.name.slice(0, 14), TRACK_COLORS[state.tracks.length % TRACK_COLORS.length]);
        state.tracks.push(t); targetId = t.id;
      }
      const clip = makeClip(audioBuffer, wf, state.playhead);
      findTrack(targetId).clips.push(clip);
      state.status = `Importado: ${file.name}`;
    } catch (err) { state.status = `Formato não suportado: ${file.name}`; }
  }
  e.target.value = '';
  render();
}

/* ==========================================================================
   EDIÇÃO: dividir, apagar, mover, aparar
   ========================================================================== */
function splitSelected() {
  if (!state.selected) { state.status = 'Selecciona um clip primeiro'; render(); return; }
  const t = findTrack(state.selected.trackId);
  const clip = t?.clips.find(c => c.id === state.selected.clipId);
  if (!clip) return;
  if (state.playhead <= clip.offset || state.playhead >= clipEnd(clip)) { state.status = 'Posiciona o cursor dentro do clip para dividir'; render(); return; }
  const cutAt = clip.trimStart + (state.playhead - clip.offset);
  const idx = t.clips.indexOf(clip);
  const left = { ...clip, trimEnd: cutAt };
  const right = { ...clip, id: 'c' + nextClipId++, offset: state.playhead, trimStart: cutAt };
  t.clips.splice(idx, 1, left, right);
  state.status = 'Clip dividido'; render();
}
function deleteSelected() {
  if (!state.selected) return;
  const t = findTrack(state.selected.trackId);
  t.clips = t.clips.filter(c => c.id !== state.selected.clipId);
  state.selected = null; state.status = 'Clip apagado'; render();
}

/* ==========================================================================
   CADEIA DE ÁUDIO (EQ, compressor, reverb, delay, denoiser, autotune)
   ========================================================================== */
function buildChain(ctx, t, clip, destination, forOffline) {
  const extraNodes = [];
  const src = ctx.createBufferSource();
  src.buffer = clip.buffer;
  let node = src;
  if (t.denoise > 0) { const dn = createDenoiseNode(ctx, t.id, liveSettings); node.connect(dn); node = dn; extraNodes.push(dn); }
  if (t.autotuneOn) { const at = createAutotuneNode(ctx, t.id, liveSettings); node.connect(at); node = at; extraNodes.push(at); }
  const low = ctx.createBiquadFilter(); low.type = 'lowshelf'; low.frequency.value = 200; low.gain.value = t.low;
  const presence = ctx.createBiquadFilter(); presence.type = 'peaking'; presence.frequency.value = 2500; presence.Q.value = 1; presence.gain.value = t.presence;
  const high = ctx.createBiquadFilter(); high.type = 'highshelf'; high.frequency.value = 3400; high.gain.value = t.high;
  node.connect(low); low.connect(presence); presence.connect(high); node = high;
  if (t.comp) { const comp = ctx.createDynamicsCompressor(); comp.threshold.value = -24; comp.ratio.value = 4; node.connect(comp); node = comp; }
  const gain = ctx.createGain(); gain.gain.value = dbToGain(t.volume);
  const pan = ctx.createStereoPanner ? ctx.createStereoPanner() : null;
  if (pan) pan.pan.value = t.pan / 50;
  const wetSum = (t.reverb + t.delayMix / 100);
  const dryGain = ctx.createGain(); dryGain.gain.value = Math.max(0.3, 1 - wetSum * 0.4);
  node.connect(dryGain);
  let reverbWet = null;
  if (t.reverb > 0) { const conv = ctx.createConvolver(); conv.buffer = getReverbIR(ctx); reverbWet = ctx.createGain(); reverbWet.gain.value = t.reverb; node.connect(conv); conv.connect(reverbWet); }
  let delayWet = null;
  if (t.delayMix > 0) { const dly = ctx.createDelay(2.0); dly.delayTime.value = t.delayTime; const fb = ctx.createGain(); fb.gain.value = t.delayFeedback; delayWet = ctx.createGain(); delayWet.gain.value = t.delayMix / 100; node.connect(dly); dly.connect(fb); fb.connect(dly); dly.connect(delayWet); }
  const mixPoint = pan || gain;
  dryGain.connect(mixPoint); if (reverbWet) reverbWet.connect(mixPoint); if (delayWet) delayWet.connect(mixPoint);
  if (pan) pan.connect(gain);
  let analyser = null;
  if (!forOffline) { analyser = ctx.createAnalyser(); analyser.fftSize = 256; gain.connect(analyser); }
  gain.connect(destination);
  return { src, analyser, extraNodes };
}
function makeMasterBus(ctx, destination) {
  const limiter = ctx.createDynamicsCompressor();
  limiter.threshold.value = state.masterCeiling; limiter.knee.value = 0; limiter.ratio.value = 20; limiter.attack.value = 0.002; limiter.release.value = 0.15;
  limiter.connect(destination);
  return limiter;
}

/* ==========================================================================
   TRANSPORTE: play / pause / stop / gravar
   ========================================================================== */
function stopPlayback(resetToZero) {
  audio.sourceNodes.forEach(({ src, extraNodes }) => { try { src.stop(); } catch (e) {} (extraNodes || []).forEach(n => { try { n.disconnect(); } catch (e) {} }); });
  audio.sourceNodes = [];
  if (audio.raf) cancelAnimationFrame(audio.raf);
  state.isPlaying = false; state.levels = {};
  if (resetToZero) state.playhead = 0;
  render();
}
function playAll() {
  syncLiveSettings();
  const ctx = getCtx();
  const hasSolo = state.tracks.some(t => t.solo);
  const maxDur = projectDuration(state.tracks);
  const startFrom = state.playhead;
  if (startFrom >= maxDur) { state.status = 'Nada mais para reproduzir — carrega em Stop para voltar ao início'; render(); return; }
  audio.sourceNodes = [];
  const masterBus = makeMasterBus(ctx, ctx.destination);
  const now = ctx.currentTime + 0.05;
  state.tracks.forEach(t => {
    const audible = hasSolo ? t.solo : !t.mute;
    if (!audible) return;
    t.clips.forEach(clip => {
      const cEnd = clipEnd(clip);
      if (cEnd <= startFrom) return;
      const { src, analyser, extraNodes } = buildChain(ctx, t, clip, masterBus, false);
      if (clip.offset >= startFrom) src.start(now + (clip.offset - startFrom), clip.trimStart, clip.trimEnd - clip.trimStart);
      else { const bufOffset = clip.trimStart + (startFrom - clip.offset); src.start(now, bufOffset, cEnd - startFrom); }
      audio.sourceNodes.push({ src, analyser, extraNodes, id: t.id });
    });
  });
  audio.playStart = { perf: performance.now(), resumeFrom: startFrom };
  state.isPlaying = true; state.status = 'A reproduzir...'; render();
  const buf = new Uint8Array(128);
  const tick = () => {
    const elapsed = (performance.now() - audio.playStart.perf) / 1000;
    const cur = audio.playStart.resumeFrom + elapsed;
    state.playhead = cur;
    const lv = {};
    audio.sourceNodes.forEach(({ analyser, id }) => {
      if (!analyser) return;
      analyser.getByteTimeDomainData(buf);
      let sum = 0; for (let i = 0; i < buf.length; i++) { const v = (buf[i] - 128) / 128; sum += v * v; }
      lv[id] = Math.sqrt(sum / buf.length);
    });
    state.levels = lv;
    updatePlaybackDOM(cur, maxDur, lv);
    if (cur >= maxDur) { stopPlayback(false); state.status = 'Reprodução terminada'; render(); return; }
    audio.raf = requestAnimationFrame(tick);
  };
  audio.raf = requestAnimationFrame(tick);
}
function updatePlaybackDOM(cur, maxDur, lv) {
  const ph = document.querySelector('.playhead-line');
  if (ph) ph.style.left = (92 + cur * state.pxPerSec) + 'px';
  const tr = document.querySelector('.time-readout');
  if (tr) tr.textContent = `${fmtTime(cur)} / ${fmtTime(maxDur)}`;
  Object.entries(lv).forEach(([id, v]) => {
    const pct = Math.min(100, v * 220);
    const bar = document.querySelector(`[data-level-bar="${id}"]`);
    if (bar) bar.style.width = pct + '%';
    const meter = document.querySelector(`[data-meter-fill="${id}"]`);
    if (meter) meter.style.height = pct + '%';
  });
}

async function exportMixdown() {
  const maxDur = projectDuration(state.tracks);
  if (maxDur <= 10 && state.tracks.every(t => t.clips.length === 0)) { state.status = 'Nada para exportar'; render(); return; }
  state.isExporting = true; state.status = `A gerar mixdown (${state.exportRate / 1000}kHz / ${state.exportBits}-bit)...`; render();
  try {
    const offline = new OfflineAudioContext(2, Math.ceil(maxDur * state.exportRate) + state.exportRate, state.exportRate);
    const masterBus = makeMasterBus(offline, offline.destination);
    const hasSolo = state.tracks.some(t => t.solo);
    state.tracks.forEach(t => {
      const audible = hasSolo ? t.solo : !t.mute;
      if (!audible) return;
      t.clips.forEach(clip => { const { src } = buildChain(offline, t, clip, masterBus, true); src.start(clip.offset, clip.trimStart, clip.trimEnd - clip.trimStart); });
    });
    const rendered = await offline.startRendering();
    const wavBlob = bufferToWav(rendered, state.exportBits);
    if (window.AndroidBridge && window.AndroidBridge.saveWavFile) {
      const reader = new FileReader();
      reader.onloadend = () => {
        const base64 = reader.result.split(',')[1];
        window.AndroidBridge.saveWavFile(base64, `lennium-mixdown-${state.exportRate}hz-${state.exportBits}bit.wav`);
      };
      reader.readAsDataURL(wavBlob);
    } else {
      const url = URL.createObjectURL(wavBlob);
      const a = document.createElement('a'); a.href = url; a.download = `lennium-mixdown-${state.exportRate}hz-${state.exportBits}bit.wav`;
      document.body.appendChild(a); a.click(); document.body.removeChild(a);
      URL.revokeObjectURL(url);
    }
    state.status = 'Mixdown WAV exportado';
  } catch (err) { state.status = 'Erro ao exportar mixdown'; }
  state.isExporting = false; render();
}

/* ==========================================================================
   INTERFACE — geração de HTML e eventos
   ========================================================================== */
function hexLogoSVG() {
  return `<svg class="hexlogo" width="24" height="24" viewBox="0 0 100 100">
    <polygon points="50,5 90,27 90,73 50,95 10,73 10,27" fill="none" stroke="url(#g)" stroke-width="4"/>
    <defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#2dd4bf"/><stop offset="1" stop-color="#22d3ee"/></linearGradient></defs>
    <path d="M35 30 L35 65 Q35 72 45 72 L55 72 M55 35 L62 50 L68 40 L74 60" stroke="url(#g)" stroke-width="5" fill="none" stroke-linecap="round" stroke-linejoin="round"/>
  </svg>`;
}
function iconSvg(name) {
  const icons = {
    upload: '<path d="M12 3v12M7 8l5-5 5 5M5 21h14"/>',
    download: '<path d="M12 3v12M7 12l5 5 5-5M5 21h14"/>',
    folder: '<path d="M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V7z"/>',
    settings: '<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.9l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.9-.3 1.7 1.7 0 0 0-1 1.6V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1-1.6 1.7 1.7 0 0 0-1.9.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.9 1.7 1.7 0 0 0-1.6-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.6-1 1.7 1.7 0 0 0-.3-1.9l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.9.3H9a1.7 1.7 0 0 0 1-1.6V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.6 1.7 1.7 0 0 0 1.9-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.9V9a1.7 1.7 0 0 0 1.6 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.6 1z"/>',
    play: '<polygon points="6,4 20,12 6,20"/>', pause: '<rect x="6" y="4" width="4" height="16"/><rect x="14" y="4" width="4" height="16"/>',
    circle: '<circle cx="12" cy="12" r="8"/>', square: '<rect x="5" y="5" width="14" height="14"/>',
    plus: '<path d="M12 5v14M5 12h14"/>', x: '<path d="M18 6 6 18M6 6l12 12"/>',
    scissors: '<circle cx="6" cy="6" r="3"/><circle cx="6" cy="18" r="3"/><path d="M20 4 8.5 15.5M8.5 8.5 20 20M6 9v6"/>',
    trash: '<path d="M3 6h18M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2m-1 0v14a2 2 0 0 1-2 2H9a2 2 0 0 1-2-2V6"/>',
    zoomIn: '<circle cx="11" cy="11" r="7"/><path d="M21 21l-4.3-4.3M11 8v6M8 11h6"/>',
    zoomOut: '<circle cx="11" cy="11" r="7"/><path d="M21 21l-4.3-4.3M8 11h6"/>',
    mic: '<path d="M12 2a3 3 0 0 0-3 3v6a3 3 0 0 0 6 0V5a3 3 0 0 0-3-3z"/><path d="M19 10v1a7 7 0 0 1-14 0v-1M12 18v4"/>',
    wind: '<path d="M3 8h11a3 3 0 1 0-3-3M3 16h15a3 3 0 1 1-3 3"/>',
    sliders: '<path d="M4 21V14M4 10V3M12 21v-8M12 9V3M20 21v-6M20 11V3M2 14h4M10 9h4M18 11h4"/>',
    waves: '<path d="M2 12c2-4 4-4 6 0s4 4 6 0 4-4 6 0M2 18c2-4 4-4 6 0s4 4 6 0 4-4 6 0"/>',
  };
  return `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">${icons[name] || ''}</svg>`;
}

function knobHTML(trackId, field, value, min, max, step, label, color, icon) {
  const pct = (value - min) / (max - min);
  const angle = -135 + pct * 270;
  return `<div class="knob-wrap">
    <div class="knob-circle"><div class="knob-indicator" style="transform:rotate(${angle}deg);background:${color}"></div>${icon ? `<span style="position:absolute;top:6px;left:6px;opacity:.5;width:11px;height:11px;color:${color}">${iconSvg('waves')}</span>` : ''}</div>
    <span class="knob-label">${label}</span>
    <input class="knob-slider" type="range" min="${min}" max="${max}" step="${step}" value="${value}" data-knob data-track="${trackId}" data-field="${field}"/>
  </div>`;
}
function miniBtnHTML(trackId, field, active, colorClass, label, full) {
  return `<button class="mini-btn ${active ? 'active-' + colorClass : ''} ${full ? 'full' : ''}" data-action="toggle-${field}" data-track="${trackId}">${label}</button>`;
}

function renderHeader() {
  return `
  <div class="header">
    <div class="logo-row">${hexLogoSVG()}<span class="brand">LENNIUM <span class="thin">STUDIO</span></span></div>
    <div class="project-nav"><span class="project-label">PROJECT · ${state.tracks.length}/${MAX_TRACKS} FAIXAS</span></div>
    <div class="header-icons">
      <button class="icon-btn" data-action="import" title="Importar áudio">${iconSvg('upload')}</button>
      <button class="icon-btn ${state.isExporting ? 'active' : ''}" data-action="export" title="Exportar mixdown">${iconSvg('download')}</button>
      <span class="icon-btn">${iconSvg('folder')}</span>
      <span class="icon-btn">${iconSvg('settings')}</span>
    </div>
  </div>`;
}
function renderViewToggle() {
  const views = [['timeline', 'Timeline'], ['mixer', 'Mixer'], ['fx', 'FX']];
  const tabs = views.map(([v, l]) => `<button class="toggle-btn ${state.view === v ? 'active' : ''}" data-action="set-view" data-view="${v}">${l}</button>`).join('');
  const zoom = state.view === 'timeline' ? `
    <div class="zoom-controls">
      <button class="zoom-btn" data-action="zoom-out">${iconSvg('zoomOut')}</button>
      <button class="zoom-btn" data-action="zoom-in">${iconSvg('zoomIn')}</button>
      <button class="zoom-btn ${state.selected ? 'active' : ''}" data-action="split" title="Dividir no cursor">${iconSvg('scissors')}</button>
      <button class="zoom-btn danger ${state.selected ? 'active' : ''}" data-action="delete-clip" title="Apagar clip">${iconSvg('trash')}</button>
    </div>` : '';
  return `<div class="view-toggle">${tabs}${zoom}</div>`;
}

function trackHeadHTML(t) {
  return `
  <div class="track-head">
    <div class="track-head-top">
      <div class="track-name-row"><span class="track-dot" style="background:${t.color}"></span><span class="track-name">${t.name}</span></div>
      <span class="track-remove" data-action="remove-track" data-track="${t.id}">${iconSvg('x')}</span>
    </div>
    <div class="mini-btns">
      ${miniBtnHTML(t.id, 'arm', t.armed, 'r', 'R')}
      ${miniBtnHTML(t.id, 'solo', t.solo, 's', 'S')}
      ${miniBtnHTML(t.id, 'mute', t.mute, 'm', 'M')}
    </div>
    <div class="tag-row">
      ${t.autotuneOn ? '<span class="tag" style="color:#a78bfa;border-color:#a78bfa">AT</span>' : ''}
      ${t.denoise > 0 ? '<span class="tag" style="color:#34d399;border-color:#34d399">DN</span>' : ''}
    </div>
    <div class="level-bar-track"><div class="level-bar-fill" data-level-bar="${t.id}" style="width:${Math.min(100, (state.levels[t.id] || 0) * 220)}%;background:${t.color}"></div></div>
  </div>`;
}
function clipHTML(t, c) {
  const isSel = state.selected && state.selected.trackId === t.id && state.selected.clipId === c.id;
  const w = Math.max(6, (c.trimEnd - c.trimStart) * state.pxPerSec);
  const left = c.offset * state.pxPerSec;
  const N = c.waveform.length;
  const startIdx = Math.floor((c.trimStart / c.bufferDuration) * N);
  const endIdx = Math.max(startIdx + 1, Math.ceil((c.trimEnd / c.bufferDuration) * N));
  const slice = c.waveform.slice(startIdx, endIdx);
  const bars = slice.map((v, i) => `<rect x="${i}" y="${23 - v * 21}" width="1" height="${Math.max(1, v * 42)}" fill="${t.color}" opacity="0.85"/>`).join('');
  return `<div class="clip ${isSel ? 'selected' : ''}" style="left:${left}px;width:${w}px;border-color:${isSel ? '#2dd4bf' : t.color + '77'}" data-clip="${c.id}" data-track="${t.id}">
    <svg width="100%" height="46" viewBox="0 0 ${slice.length} 46" preserveAspectRatio="none">${bars}</svg>
    <div class="trim-handle left" data-trim="left" data-clip="${c.id}" data-track="${t.id}"></div>
    <div class="trim-handle right" data-trim="right" data-clip="${c.id}" data-track="${t.id}"></div>
  </div>`;
}
function trackLaneHTML(t, totalPx) {
  const clips = t.clips.map(c => clipHTML(t, c)).join('');
  const empty = t.clips.length === 0 ? `<span class="empty-lane">vazio — grava (R) ou importa áudio</span>` : '';
  return `<div class="track-lane" style="width:${totalPx}px">${clips}${empty}</div>`;
}
function renderTimeline() {
  const maxDur = projectDuration(state.tracks);
  const totalPx = Math.max(600, maxDur * state.pxPerSec);
  const rulerStep = state.pxPerSec > 40 ? 5 : state.pxPerSec > 15 ? 15 : 60;
  let marks = '';
  for (let s = 0; s <= maxDur + rulerStep; s += rulerStep) marks += `<span class="ruler-mark" style="left:${s * state.pxPerSec}px">${fmtTime(s)}</span>`;
  const rows = state.tracks.map(t => `<div class="track-row">${trackHeadHTML(t)}${trackLaneHTML(t, totalPx)}</div>`).join('');
  return `
  <div class="timeline-outer" id="timelineOuter">
    <div class="timeline-inner" style="width:${92 + totalPx}px">
      <div class="ruler" id="ruler">
        <div class="ruler-spacer"></div>
        <div class="ruler-marks" style="width:${totalPx}px">${marks}</div>
        <button class="add-track-btn" data-action="add-track">${iconSvg('plus')}</button>
      </div>
      <div class="playhead-line" style="left:${92 + state.playhead * state.pxPerSec}px"></div>
      ${rows}
    </div>
  </div>`;
}

function channelStripHTML(t) {
  return `
  <div class="channel-strip">
    <div class="insert-slot">L-Plugins</div>
    <button class="comp-btn ${t.comp ? 'on' : ''}" style="--tc:${t.color}" data-action="toggle-comp" data-track="${t.id}">${iconSvg('sliders').replace('viewBox','width="9" height="9" viewBox')} COMP</button>
    ${knobHTML(t.id, 'low', t.low, -12, 12, 1, 'Low', t.color)}
    ${knobHTML(t.id, 'presence', t.presence, -12, 12, 1, 'Mid', t.color)}
    ${knobHTML(t.id, 'high', t.high, -12, 12, 1, 'High', t.color)}
    ${knobHTML(t.id, 'pan', t.pan, -50, 50, 1, 'Pan', t.color)}
    ${knobHTML(t.id, 'reverb', t.reverb, 0, 1, 0.05, 'Verb', t.color, true)}
    <div class="mini-btns" style="margin-top:4px">${miniBtnHTML(t.id, 'solo', t.solo, 's', 'S')}${miniBtnHTML(t.id, 'mute', t.mute, 'm', 'M')}</div>
    ${miniBtnHTML(t.id, 'arm', t.armed, 'r', 'R', true)}
    <div class="fader-row">
      <input class="fader" type="range" min="-40" max="10" value="${t.volume}" orient="vertical" data-knob data-track="${t.id}" data-field="volume"/>
      <div class="meter-track"><div class="meter-fill" data-meter-fill="${t.id}" style="height:${Math.min(100, (state.levels[t.id] || 0) * 220)}%;background:${t.color}"></div></div>
    </div>
    <span class="channel-name">${t.name}</span>
    <span style="height:3px;width:100%;background:${t.color};border-radius:2px"></span>
  </div>`;
}
function renderMixer() { return `<div class="mixer-area">${state.tracks.map(channelStripHTML).join('')}</div>`; }

function fxCardHTML(t) {
  return `
  <div class="fx-card">
    <div class="fx-card-head">
      <span style="width:8px;height:8px;border-radius:4px;background:${t.color}"></span>
      <span class="fx-track-name">${t.name}</span>
      <button class="preset-btn" data-action="voice-preset" data-track="${t.id}">${iconSvg('mic').replace('viewBox','width="10" height="10" viewBox')} Voz</button>
    </div>
    <div class="fx-row">
      <div class="fx-label-wrap"><span style="width:11px;height:11px;color:#34d399">${iconSvg('wind')}</span><span class="fx-label">Denoiser</span></div>
      <input class="fx-slider" type="range" min="0" max="100" value="${t.denoise}" data-knob data-track="${t.id}" data-field="denoise"/>
      <span class="fx-value">${t.denoise}%</span>
    </div>
    <div class="fx-row">
      <div class="fx-label-wrap">
        <button class="small-toggle ${t.autotuneOn ? 'on' : ''}" data-action="toggle-autotune" data-track="${t.id}">AT</button>
        <span class="fx-label">Autotune</span>
      </div>
      <select class="key-select" data-select data-track="${t.id}" data-field="autotuneKey">${NOTE_NAMES.map(n => `<option value="${n}" ${t.autotuneKey === n ? 'selected' : ''}>${n}</option>`).join('')}</select>
      <input class="fx-slider" type="range" min="0" max="100" value="${t.autotuneAmount}" data-knob data-track="${t.id}" data-field="autotuneAmount"/>
    </div>
    <div class="fx-row">
      <div class="fx-label-wrap"><span class="fx-label">Delay t/fb/mix</span></div>
      <input class="fx-slider" type="range" min="0.05" max="1" step="0.01" value="${t.delayTime}" data-knob data-track="${t.id}" data-field="delayTime"/>
      <input class="fx-slider" type="range" min="0" max="0.85" step="0.01" value="${t.delayFeedback}" data-knob data-track="${t.id}" data-field="delayFeedback"/>
      <input class="fx-slider" type="range" min="0" max="100" value="${t.delayMix}" data-knob data-track="${t.id}" data-field="delayMix"/>
    </div>
  </div>`;
}
function renderFx() {
  return `<div class="fx-area">
    ${state.tracks.map(fxCardHTML).join('')}
    <div class="master-card">
      <div class="master-row">
        <span class="fx-track-name">Master — Limiter</span>
        <input class="fx-slider" type="range" min="-12" max="0" step="0.5" value="${state.masterCeiling}" data-master="ceiling"/>
        <span class="fx-value">${state.masterCeiling}dB</span>
      </div>
      <div class="master-row">
        <span class="fx-label">Exportar em</span>
        <select class="key-select" data-master="rate">
          <option value="44100" ${state.exportRate === 44100 ? 'selected' : ''}>44.1 kHz</option>
          <option value="48000" ${state.exportRate === 48000 ? 'selected' : ''}>48 kHz</option>
          <option value="96000" ${state.exportRate === 96000 ? 'selected' : ''}>96 kHz</option>
        </select>
        <select class="key-select" data-master="bits">
          <option value="16" ${state.exportBits === 16 ? 'selected' : ''}>16-bit</option>
          <option value="24" ${state.exportBits === 24 ? 'selected' : ''}>24-bit</option>
        </select>
        <span class="fx-label" style="opacity:.7">WAV (sem perdas)</span>
      </div>
    </div>
  </div>`;
}

function renderTransport() {
  const maxDur = projectDuration(state.tracks);
  return `
  <div class="transport">
    <button class="transport-btn" data-action="play-pause">${iconSvg(state.isPlaying ? 'pause' : 'play')}</button>
    <button class="transport-btn rec ${state.isRecording ? 'on' : ''}" data-action="record">${iconSvg('circle')}</button>
    <button class="transport-btn stop" data-action="stop">${iconSvg('square')}</button>
    <span class="time-readout">${fmtTime(state.playhead)} / ${fmtTime(maxDur)}</span>
  </div>`;
}

function render() {
  const root = document.getElementById('root');
  const scrollLeft = document.getElementById('timelineOuter')?.scrollLeft || 0;
  root.innerHTML = `
    ${renderHeader()}
    ${renderViewToggle()}
    <div class="status-bar">${state.status}</div>
    ${state.view === 'timeline' ? renderTimeline() : state.view === 'mixer' ? renderMixer() : renderFx()}
    ${renderTransport()}
  `;
  const to = document.getElementById('timelineOuter');
  if (to) to.scrollLeft = scrollLeft;
  attachListeners();
}

/* ==========================================================================
   EVENTOS
   ========================================================================== */
let dragState = null;

function attachListeners() {
  const root = document.getElementById('root');

  root.querySelectorAll('[data-action]').forEach(el => {
    el.addEventListener('click', (e) => {
      const action = el.dataset.action;
      const trackId = el.dataset.track;
      switch (action) {
        case 'set-view': state.view = el.dataset.view; render(); break;
        case 'add-track': addTrack(); break;
        case 'remove-track': removeTrack(trackId); break;
        case 'toggle-arm': toggleArm(trackId); break;
        case 'toggle-solo': toggleSolo(trackId); break;
        case 'toggle-mute': toggleMute(trackId); break;
        case 'toggle-comp': toggleComp(trackId); break;
        case 'toggle-autotune': toggleAutotune(trackId); break;
        case 'voice-preset': applyVoicePreset(trackId); break;
        case 'zoom-in': state.pxPerSec = Math.min(120, state.pxPerSec + 4); render(); break;
        case 'zoom-out': state.pxPerSec = Math.max(4, state.pxPerSec - 4); render(); break;
        case 'split': splitSelected(); break;
        case 'delete-clip': deleteSelected(); break;
        case 'import': triggerImport(); break;
        case 'export': exportMixdown(); break;
        case 'play-pause': state.isPlaying ? stopPlayback(false) : playAll(); break;
        case 'record': state.isRecording ? stopRecording() : startRecording(); break;
        case 'stop': stopPlayback(true); stopRecording(); break;
      }
    });
  });

  root.querySelectorAll('[data-knob]').forEach(el => {
    el.addEventListener('input', () => {
      const trackId = el.dataset.track, field = el.dataset.field;
      updateTrack(trackId, { [field]: Number(el.value) });
      render();
    });
  });
  root.querySelectorAll('[data-select]').forEach(el => {
    el.addEventListener('change', () => { updateTrack(el.dataset.track, { [el.dataset.field]: el.value }); render(); });
  });
  root.querySelectorAll('[data-master]').forEach(el => {
    el.addEventListener('input', () => {
      const key = el.dataset.master;
      if (key === 'ceiling') state.masterCeiling = Number(el.value);
      if (key === 'rate') state.exportRate = Number(el.value);
      if (key === 'bits') state.exportBits = Number(el.value);
      render();
    });
  });

  // Selecção + arrastar clips (mover / aparar)
  root.querySelectorAll('.clip').forEach(el => {
    el.addEventListener('pointerdown', (e) => {
      if (e.target.closest('.trim-handle')) return;
      const trackId = el.dataset.track, clipId = el.dataset.clip;
      state.selected = { trackId, clipId };
      const t = findTrack(trackId); const c = t.clips.find(c => c.id === clipId);
      dragState = { mode: 'move', trackId, clipId, startX: e.clientX, offset: c.offset, trimStart: c.trimStart, trimEnd: c.trimEnd, el };
      el.setPointerCapture(e.pointerId);
      root.querySelectorAll('.clip').forEach(c2 => c2.classList.remove('selected'));
      el.classList.add('selected');
    });
  });
  root.querySelectorAll('.trim-handle').forEach(el => {
    el.addEventListener('pointerdown', (e) => {
      e.stopPropagation();
      const trackId = el.dataset.track, clipId = el.dataset.clip;
      const side = el.dataset.trim;
      state.selected = { trackId, clipId };
      const t = findTrack(trackId); const c = t.clips.find(c => c.id === clipId);
      dragState = { mode: side === 'left' ? 'trimLeft' : 'trimRight', trackId, clipId, startX: e.clientX, offset: c.offset, trimStart: c.trimStart, trimEnd: c.trimEnd, el: el.closest('.clip') };
      el.setPointerCapture(e.pointerId);
    });
  });

  // Régua: clicar para posicionar o cursor (seek)
  const ruler = document.getElementById('ruler');
  if (ruler) {
    ruler.addEventListener('pointerdown', (e) => {
      if (e.target.closest('.add-track-btn')) return;
      const rect = ruler.getBoundingClientRect();
      const t = Math.max(0, (e.clientX - rect.left - 92) / state.pxPerSec);
      const wasPlaying = state.isPlaying;
      if (wasPlaying) stopPlayback(false);
      state.playhead = t;
      if (wasPlaying) playAll(); else render();
    });
  }
}

document.addEventListener('pointermove', (e) => {
  if (!dragState) return;
  const deltaSec = (e.clientX - dragState.startX) / state.pxPerSec;
  const t = findTrack(dragState.trackId);
  const c = t.clips.find(c => c.id === dragState.clipId);
  if (!c) return;
  if (dragState.mode === 'move') {
    c.offset = Math.max(0, dragState.offset + deltaSec);
    dragState.el.style.left = (c.offset * state.pxPerSec) + 'px';
  } else if (dragState.mode === 'trimLeft') {
    const newStart = Math.max(0, Math.min(dragState.trimStart + deltaSec, dragState.trimEnd - 0.05));
    c.offset = Math.max(0, dragState.offset + (newStart - dragState.trimStart));
    c.trimStart = newStart;
    dragState.el.style.left = (c.offset * state.pxPerSec) + 'px';
    dragState.el.style.width = Math.max(6, (c.trimEnd - c.trimStart) * state.pxPerSec) + 'px';
  } else if (dragState.mode === 'trimRight') {
    c.trimEnd = Math.max(dragState.trimStart + 0.05, dragState.trimEnd + deltaSec);
    dragState.el.style.width = Math.max(6, (c.trimEnd - c.trimStart) * state.pxPerSec) + 'px';
  }
});
document.addEventListener('pointerup', () => { if (dragState) { dragState = null; render(); } });

document.getElementById('fileImport').addEventListener('change', handleImportFiles);

/* ==========================================================================
   ARRANQUE
   ========================================================================== */
render();
